﻿namespace Actividad2
{
    public class Actividad2_semana10
{
    public static void Main()
    {
        //Sebastian Villeda
        //Carné: 1032625
        //Actividad 2 Semana 10 arreglos
        while(true)
        {
        try
        {
        Console.WriteLine("Ingrese 8 numeros por favor");
        double[] lista_de_numeros= new double [8];
        double sumaDeNumeros;
        double promedio;
        for (int i=0; i< lista_de_numeros.GetLength(0); i++)
        {
            lista_de_numeros[i]= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("El numero "+(i+1)+" del arreglo es: " +lista_de_numeros[i]);
        }
        Console.WriteLine("");
        sumaDeNumeros = Math.Round(lista_de_numeros.Sum(),3);
        Console.WriteLine("La suma de todos los numeros del arreglo es: "+sumaDeNumeros);
        Console.WriteLine("");
        promedio = Math.Round(lista_de_numeros.Average(),3);
        Console.WriteLine("El promedio de todos los numeros del arreglo es: "+promedio);
        Console.WriteLine("");
        break;
        }catch(FormatException)
        {
         Console.WriteLine("Error al ingresar los números, presione enter para volver a intentarlo");
         Console.ReadLine();
         Console.Clear();
        }
            }
        }
    }
}
