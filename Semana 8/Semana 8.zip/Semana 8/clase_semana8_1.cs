﻿
namespace Actividad1Semana8
{
public class Actividad1_Semana8
{
    public static void Main()
    {
        string prueba ;
        double numero ;
        while(true)
        {
            Console.WriteLine("Escriba el numero del que quiere econtrar el factorial");
            prueba = Console.ReadLine() ??"";
            if(double.TryParse(prueba, out numero))
            {

            }
            else
            {    
                Console.WriteLine("Valor no permitido, por favor ingrese otro valor");
            break;
            }
            numero = double.Parse(prueba);
            double numeroAproximado = Math.Round(numero,0);
            double factorial;
            factorial = CalcularFactorial(numeroAproximado);
        
            switch(numeroAproximado)
            {
                case>=0:
                    Console.WriteLine("Su numero es "+numeroAproximado);
                    Console.WriteLine("El factorial del numero que ingreso es "+factorial);
                break;
                default:
                    Console.WriteLine("Valor no permitido, por favor ingrese otro valor");
                break;
            }      
            break;    
        }
    }
    public static double CalcularFactorial(double numeroAproximado)
    {
        if (numeroAproximado == 0)
        {   
            return 1;
        }
        else    
        {
            double factorial = 1;
            for (int i = 1; i<= numeroAproximado; i++)
            {
                factorial *= i;
            }
            return factorial;    
        }
    }    

    }  
        }
        
    
 
