﻿using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;

namespace Actividad1semana7_SebastianVilleda
{
    class Actividad1semana7
    {
        static void Main(String[] args)
        {  
            string miNombre= " Sebastian Alexander Villeda Reyna"; 
            Console.WriteLine(miNombre.Trim().ToUpper());
            Console.WriteLine(miNombre.Contains("Sebastian"));
            Console.WriteLine("Hola!");
            Console.WriteLine("a"== "a");
            Console.WriteLine(2 != 3);
            Console.WriteLine(1 >= 2);
        
            
        }
        }
    }