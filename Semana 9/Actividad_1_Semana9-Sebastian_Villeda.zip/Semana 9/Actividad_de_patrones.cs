﻿using System.Security.Cryptography.X509Certificates;

namespace Actividad1Semana9
{
public class Actividad1_Semana9
{
    public static void Main()
    {
        //Sebastian Villeda
        //Carné: 1032625
    int numero ;
    Console.WriteLine("Bienvenido Usuario, por favor ingrese un número no mayor a 6 cifras");
    numero = Math.Abs(Convert.ToInt32(Console.ReadLine()));
    Console.WriteLine("Su numero es "+numero);
    int numeroDos= ValidacionNumero(numero);
             if(numero<=1 || numero>1000000)
         {
            Console.WriteLine("Valor no permitido");
         }
         else if(numero==2 || numero==3)
        {
            Console.WriteLine("El numero es primo");
        }
        else if(numeroDos==0)
        {
            Console.WriteLine("El numero es primo");
        }
        else if(numeroDos==1)
        {
             Console.WriteLine("El numero no es primo");
        }
}
    public static int ValidacionNumero(int numero)
    {
              for(int i = 2; i<=Math.Sqrt(numero); i++)
        {
            if(numero%i==0)
            {
                return 1;
                     
            }
        }  
         return 0;    
    }

     
    }  
 }
